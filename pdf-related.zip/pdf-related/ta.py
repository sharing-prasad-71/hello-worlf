import os
from datetime import datetime
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fpdf import FPDF
from PyPDF2 import PdfReader, PdfWriter

app = FastAPI()

# Paths
TEMPLATE_PDF_PATH = r"img.pdf"
OUTPUT_DIR = r"certificates"

class CertificateRequest(BaseModel):
    user_id: str
    course_id: str
    user_name: str
    course_name: str
    created_at: str


class CertificatePDF(FPDF):
    pass


def fit_text_in_width(pdf, text, max_width, font_name, font_style, max_font_size, min_font_size):
    font_size = max_font_size
    pdf.set_font(font_name, font_style, font_size)
    while pdf.get_string_width(text) > max_width and font_size > min_font_size:
        font_size -= 1
        pdf.set_font(font_name, font_style, font_size)
    return font_size


def generate_certificate_pdf(user_name, course_name, created_at, user_id, course_id) -> str:
    try:
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        temp_overlay_path = os.path.join(OUTPUT_DIR, "temp_overlay.pdf")

        # Read page size from template
        template_reader = PdfReader(TEMPLATE_PDF_PATH)
        page = template_reader.pages[0]
        width = float(page.mediabox.width) * 0.352778  # pt to mm
        height = float(page.mediabox.height) * 0.352778

        # Create overlay with same page size
        pdf = CertificatePDF(orientation='P', format=(width, height))
        pdf.add_page()

        # Define areas (relative positions)
        center_x = width / 2
        max_width = width * 0.6  # 60% of width
        min_font_size = 10

        # USER NAME (roughly upper middle)
        font_size_name = fit_text_in_width(pdf, user_name.upper(), max_width, "Helvetica", "B", 28, min_font_size)
        pdf.set_font("Helvetica", "B", font_size_name)
        pdf.set_xy(center_x - (max_width / 2), height * 0.45)
        pdf.cell(w=max_width, h=15, txt=user_name.upper(), border=0, align="C")

        # COURSE NAME (a bit lower)
        font_size_course = fit_text_in_width(pdf, course_name, max_width, "Helvetica", "", 18, min_font_size)
        pdf.set_font("Helvetica", "", font_size_course)
        pdf.set_xy(center_x - (max_width / 2), height * 0.55)
        pdf.cell(w=max_width, h=10, txt=course_name, border=0, align="C")

        # DATE (bottom right corner area)
        formatted_date = datetime.strptime(created_at.split("T")[0], "%Y-%m-%d").strftime("%d/%m/%Y")
        pdf.set_font("Helvetica", "", 14)
        pdf.set_xy(width * 0.7, height * 0.85)
        pdf.cell(w=40, h=10, txt=formatted_date, border=0, align="C")

        pdf.output(temp_overlay_path)

        # Merge overlay onto template
        overlay_reader = PdfReader(temp_overlay_path)
        writer = PdfWriter()
        base_page = template_reader.pages[0]
        base_page.merge_page(overlay_reader.pages[0])
        writer.add_page(base_page)

        final_path = os.path.join(OUTPUT_DIR, f"certificate_{user_id}_{course_id}.pdf")
        if os.path.exists(final_path):
            os.remove(final_path)

        with open(final_path, "wb") as f:
            writer.write(f)

        os.remove(temp_overlay_path)
        return final_path

    except Exception as e:
        print(f"ERROR during PDF generation: {e}")
        raise RuntimeError(f"PDF generation failed: {str(e)}")


@app.post("/generate-certificate/")
async def generate_certificate(data: CertificateRequest):
    try:
        pdf_path = generate_certificate_pdf(
            user_name=data.user_name,
            course_name=data.course_name,
            created_at=data.created_at,
            user_id=data.user_id,
            course_id=data.course_id,
        )
        return {"pdf_path": pdf_path}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Certificate generation failed: {e}")
