from __future__ import annotations

import os
import json
from datetime import datetime
from typing import Dict

from fpdf import FPDF
from PyPDF2 import PdfReader, PdfWriter

TEMPLATE_PDF_PATH = "img.pdf"
INPUT_JSON_PATH   = "file.json"
OUTPUT_DIR        = "certificates"

class CertificatePDF(FPDF):
    def header(self):
        pass
    def footer(self):
        pass

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def fit_text(pdf: CertificatePDF, text: str, box_w: float, *, style="", max_pt=48, min_pt=12) -> int:
    pt = max_pt
    pdf.set_font("Helvetica", style, pt)
    while pdf.get_string_width(text) > box_w and pt > min_pt:
        pt -= 1
        pdf.set_font("Helvetica", style, pt)
    return pt


def whiten(pdf: CertificatePDF, x: float, y: float, w: float, h: float):
    pdf.set_fill_color(255, 255, 255)
    pdf.rect(x, y, w, h, style="F")
    pdf.set_fill_color(0, 0, 0)

# ---------------------------------------------------------------------------
# Main generator
# ---------------------------------------------------------------------------

def generate_certificate_pdf(data: Dict[str, str], *, debug: bool = False) -> str:
    required = ("user_id", "course_id", "user_name", "course_name", "created_at")
    for k in required:
        if k not in data:
            raise ValueError(f"JSON missing required key: {k}")

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    out_path = os.path.join(OUTPUT_DIR, f"certificate_{data['user_id']}_{data['course_id']}.pdf")

    # Read template size
    tpl_reader = PdfReader(TEMPLATE_PDF_PATH)
    mb = tpl_reader.pages[0].mediabox
    w_mm, h_mm = float(mb.width) * 0.352777778, float(mb.height) * 0.352777778

    # Build overlay PDF with user‑specific text -----------------------------
    pdf = CertificatePDF(unit="mm", format=(w_mm, h_mm))
    pdf.set_auto_page_break(False)
    pdf.add_page()

    centre_x = w_mm / 2.0
    box_w    = w_mm * 0.70

    # Wipe placeholders (we overlay white, then write)
    name_y = h_mm * 0.46
    whiten(pdf, 0, name_y - 6, w_mm, 26)
    old_course_y = h_mm * 0.63
    whiten(pdf, 0, old_course_y, w_mm, 45)

    # Name
    pdf.set_font("Helvetica", "B", fit_text(pdf, data["user_name"], box_w, style="B", max_pt=38, min_pt=18))
    pdf.set_xy(centre_x - box_w/2, h_mm * 0.505)
    pdf.cell(box_w, 12, data["user_name"], align="C")

    # Course
    pdf.set_font("Helvetica", "B", fit_text(pdf, data["course_name"], box_w, style="B", max_pt=46, min_pt=20))
    pdf.set_xy(centre_x - box_w/2, h_mm * 0.68)
    pdf.multi_cell(box_w, 14, data["course_name"], align="C")

    # Date
    try:
        date_str = datetime.fromisoformat(data["created_at"]).strftime("%d/%m/%Y")
    except Exception:
        date_str = data["created_at"]
    pdf.set_font("Helvetica", size=12)
    pdf.set_xy(w_mm * 0.68, h_mm * 0.82)
    pdf.cell(50, 8, date_str, align="C")

    overlay_tmp = os.path.join(OUTPUT_DIR, "_overlay.pdf")
    pdf.output(overlay_tmp)

    # ----------------------------------------------------------------------
    # Merge strategy A: use fpdf2 import_page if available
    # ----------------------------------------------------------------------
    try:
        pdf_bg = CertificatePDF(unit="mm", format=(w_mm, h_mm))
        pdf_bg.add_page()
        # this will raise AttributeError on old PyFPDF
        tpl_id = pdf_bg.import_page(TEMPLATE_PDF_PATH, page_number=1)
        pdf_bg.use_template(tpl_id, 0, 0, w_mm, h_mm)
        # now draw overlay image onto bg
        pdf_bg.image(overlay_tmp, 0, 0, w_mm, h_mm)
        pdf_bg.output(out_path)
    except AttributeError:
        # ------------------------------------------------------------------
        # Strategy B: classic PyPDF2 merge (works anywhere)
        # ------------------------------------------------------------------
        writer = PdfWriter()
        base  = tpl_reader.pages[0]
        overlay_page = PdfReader(overlay_tmp).pages[0]
        base.merge_page(overlay_page)
        writer.add_page(base)
        with open(out_path, "wb") as fh:
            writer.write(fh)

    # Cleanup temp
    try:
        os.remove(overlay_tmp)
    except OSError:
        pass

    return out_path

# ---------------------------------------------------------------------------
# Convenience wrapper
# ---------------------------------------------------------------------------

def generate_from_json(json_path: str = INPUT_JSON_PATH, *, debug: bool = False) -> str:
    with open(json_path, "r", encoding="utf-8") as fh:
        payload = json.load(fh)
    return generate_certificate_pdf(payload, debug=debug)

if __name__ == "__main__":
    print("Generated →", generate_from_json())
