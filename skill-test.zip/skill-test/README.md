# Coalition Skills Test

Responsive HTML/CSS/JavaScript implementation of the HealthCare Dashboard - Adobe XD Template of Skills test.

## Run locally

From this folder:

```bash
python3 -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

or simply open locally in edge or Chrome browser

## Config

Edit `config.js` if you need to swap the API credentials or base URL.

```js
window.APP_CONFIG = {
  apiBaseUrl: 'https://fedskillstest.coalitiontechnologies.workers.dev',
  auth: {
    type: 'Basic',
    username: 'coalition',
    password: 'skills-test',
  },
  targetPatientName: 'Jessica Taylor',
};
```

## Notes

- Data is fetched from the Coalition Technologies patient API.
- The dashboard targets Jessica Taylor, matching the design instructions.
- If the API request fails, fallback sample data keeps the UI visible.
