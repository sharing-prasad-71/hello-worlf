window.APP_CONFIG = {
  apiBaseUrl: 'https://fedskillstest.coalitiontechnologies.workers.dev',
  auth: {
    type: 'Basic',
    username: 'coalition',
    password: 'skills-test',
  },
  targetPatientName: 'Jessica Taylor',
};
