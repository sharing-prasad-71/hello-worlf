const root = document.documentElement;
const monthOrder = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const monthShort = { January: 'Jan', February: 'Feb', March: 'Mar', April: 'Apr', May: 'May', June: 'Jun', July: 'Jul', August: 'Aug', September: 'Sep', October: 'Oct', November: 'Nov', December: 'Dec' };

const fallbackData = [
  {
    name: 'Jessica Taylor',
    gender: 'Female',
    age: 28,
    profile_picture: 'https://fedskillstest.ct.digital/4.png',
    date_of_birth: '1996-08-23',
    phone_number: '(415) 555-1234',
    emergency_contact: '(415) 555-5678',
    insurance_type: 'Sunrise Health Assurance',
    diagnosis_history: [
      { month: 'October', year: 2023, blood_pressure: { systolic: { value: 120, levels: 'Normal' }, diastolic: { value: 110, levels: 'Normal' } }, respiratory_rate: { value: 20, levels: 'Normal' }, temperature: { value: 98.6, levels: 'Normal' }, heart_rate: { value: 78, levels: 'Normal' } },
      { month: 'November', year: 2023, blood_pressure: { systolic: { value: 118, levels: 'Normal' }, diastolic: { value: 68, levels: 'Normal' } }, respiratory_rate: { value: 20, levels: 'Normal' }, temperature: { value: 98.4, levels: 'Normal' }, heart_rate: { value: 76, levels: 'Normal' } },
      { month: 'December', year: 2023, blood_pressure: { systolic: { value: 160, levels: 'Higher than average' }, diastolic: { value: 110, levels: 'Normal' } }, respiratory_rate: { value: 20, levels: 'Normal' }, temperature: { value: 98.7, levels: 'Normal' }, heart_rate: { value: 79, levels: 'Normal' } },
      { month: 'January', year: 2024, blood_pressure: { systolic: { value: 115, levels: 'Normal' }, diastolic: { value: 92, levels: 'Normal' } }, respiratory_rate: { value: 20, levels: 'Normal' }, temperature: { value: 98.6, levels: 'Normal' }, heart_rate: { value: 78, levels: 'Normal' } },
      { month: 'February', year: 2024, blood_pressure: { systolic: { value: 150, levels: 'Higher than average' }, diastolic: { value: 72, levels: 'Lower than average' } }, respiratory_rate: { value: 20, levels: 'Normal' }, temperature: { value: 98.5, levels: 'Normal' }, heart_rate: { value: 77, levels: 'Normal' } },
      { month: 'March', year: 2024, blood_pressure: { systolic: { value: 160, levels: 'Higher than average' }, diastolic: { value: 78, levels: 'Lower than average' } }, respiratory_rate: { value: 20, levels: 'Normal' }, temperature: { value: 98.6, levels: 'Normal' }, heart_rate: { value: 78, levels: 'Lower than average' } },
    ],
    diagnostic_list: [
      { name: 'Hypertension', description: 'Chronic high blood pressure', status: 'Under Observation' },
      { name: 'Asthma', description: 'Mild intermittent symptoms', status: 'Active' },
      { name: 'Allergic Rhinitis', description: 'Seasonal allergies', status: 'Managed' },
    ],
    lab_results: ['Blood Tests', 'CT Scans', 'MRI'],
  },
];

const config = window.APP_CONFIG || {};
const apiBaseUrl = config.apiBaseUrl || 'https://fedskillstest.coalitiontechnologies.workers.dev';
const auth = config.auth || { type: 'Basic', username: 'coalition', password: 'skills-test' };
const targetPatientName = (config.targetPatientName || 'Jessica Taylor').toLowerCase();

const els = {
  doctorAvatar: document.getElementById('doctorAvatar'),
  patientList: document.getElementById('patientList'),
  patientTemplate: document.getElementById('patientTemplate'),
  vitalTemplate: document.getElementById('vitalTemplate'),
  profilePicture: document.getElementById('profilePicture'),
  patientName: document.getElementById('patientName'),
  patientMeta: document.getElementById('patientMeta'),
  profileInfo: document.getElementById('profileInfo'),
  vitalGrid: document.getElementById('vitalGrid'),
  diagnosticRows: document.getElementById('diagnosticRows'),
  labResults: document.getElementById('labResults'),
  bpChart: document.getElementById('bpChart'),
  systolicValue: document.getElementById('systolicValue'),
  systolicHint: document.getElementById('systolicHint'),
  diastolicValue: document.getElementById('diastolicValue'),
  diastolicHint: document.getElementById('diastolicHint'),
};

els.doctorAvatar.src = 'https://i.pravatar.cc/100?img=12';

function getAuthHeader() {
  const token = btoa(`${auth.username}:${auth.password}`);
  return `${auth.type} ${token}`;
}

async function fetchPatients() {
  const response = await fetch(apiBaseUrl, {
    method: 'GET',
    headers: {
      Authorization: getAuthHeader(),
      Accept: 'application/json',
    },
  });
  if (!response.ok) {
    throw new Error(`Request failed: ${response.status}`);
  }
  return response.json();
}

function normalizePatients(payload) {
  if (Array.isArray(payload)) return payload;
  if (payload && Array.isArray(payload.patients)) return payload.patients;
  if (payload && typeof payload === 'object') return [payload];
  return fallbackData;
}

function findJessica(patients) {
  return patients.find((patient) => String(patient?.name || '').toLowerCase() === targetPatientName) || patients[0] || fallbackData[0];
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function sortHistory(history) {
  return [...(Array.isArray(history) ? history : [])].sort((a, b) => {
    const yearDiff = (a?.year || 0) - (b?.year || 0);
    if (yearDiff !== 0) return yearDiff;
    return monthOrder.indexOf(a?.month) - monthOrder.indexOf(b?.month);
  });
}

function patientDisplayAge(patient) {
  if (patient?.age != null) return patient.age;
  if (!patient?.date_of_birth) return '';
  const dob = new Date(patient.date_of_birth);
  if (Number.isNaN(dob.getTime())) return '';
  const diff = new Date().getFullYear() - dob.getFullYear();
  return diff;
}

function patientSubline(patient) {
  const parts = [];
  if (patient?.gender) parts.push(patient.gender);
  const age = patientDisplayAge(patient);
  if (age !== '' && age != null) parts.push(age);
  return parts.join(', ');
}

function makeVitalIcon(filename) {
  const wrap = document.createElement('div');
  wrap.className = 'vital-icon';
  const img = document.createElement('img');
  img.src = `assets/${filename}`;
  img.alt = '';
  img.setAttribute('aria-hidden', 'true');
  wrap.appendChild(img);
  return wrap;
}

function renderPatientsList(patients, query = '') {
  const template = els.patientTemplate.content.firstElementChild;
  const needle = query.trim().toLowerCase();
  const filtered = patients.filter((patient) => {
    if (!needle) return true;
    return [patient?.name, patient?.gender, patientDisplayAge(patient)].join(' ').toLowerCase().includes(needle);
  });

  els.patientList.innerHTML = '';
  if (!filtered.length) {
    els.patientList.innerHTML = '<div class="empty-state">No patients match your search.</div>';
    return;
  }

  filtered.forEach((patient) => {
    const row = template.cloneNode(true);
    const name = patient?.name || 'Unnamed patient';
    const avatar = row.querySelector('.patient-avatar');
    const imgSrc = patient?.profile_picture || fallbackData[0].profile_picture;
    avatar.src = imgSrc;
    avatar.alt = name;
    avatar.onerror = () => {
      avatar.src = fallbackData[0].profile_picture;
    };
    row.querySelector('.patient-name').textContent = name;
    row.querySelector('.patient-sub').textContent = patientSubline(patient);
    row.classList.toggle('active', String(name).toLowerCase() === targetPatientName);
    els.patientList.appendChild(row);
  });
}

function renderProfile(patient) {
  els.profilePicture.src = patient?.profile_picture || fallbackData[0].profile_picture;
  els.profilePicture.onerror = () => {
    els.profilePicture.src = fallbackData[0].profile_picture;
  };
  els.patientName.textContent = patient?.name || 'Jessica Taylor';
  els.patientMeta.textContent = patient?.gender || 'Female';

  const rows = [
    { icon: 'birth-icon.svg', label: 'Date Of Birth', value: patient?.date_of_birth ? formatDate(patient.date_of_birth) : '-' },
    { icon: 'female-icon.svg', label: 'Gender', value: patient?.gender || '-' },
    { icon: 'phone-icon.svg', label: 'Contact Info.', value: patient?.phone_number || '-' },
    { icon: 'phone-icon.svg', label: 'Emergency Contacts', value: patient?.emergency_contact || '-' },
    { icon: 'insurance-icon.svg', label: 'Insurance Provider', value: patient?.insurance_type || '-' },
  ];

  els.profileInfo.innerHTML = rows.map((row) => `
    <div class="info-row">
      <div class="info-icon"><img src="assets/${row.icon}" alt="" aria-hidden="true" /></div>
      <div class="info-copy">
        <span class="info-label">${escapeHtml(row.label)}</span>
        <span class="info-value">${escapeHtml(row.value)}</span>
      </div>
    </div>
  `).join('');
}

function renderVitals(patient) {
  const history = sortHistory(patient?.diagnosis_history || []);
  const latest = history[history.length - 1] || {};
  const items = [
    {
      icon: 'lungs.png',
      label: 'Respiratory Rate',
      value: `${latest?.respiratory_rate?.value ?? '--'} bpm`,
      status: latest?.respiratory_rate?.levels || 'Normal',
      state: latest?.respiratory_rate?.levels?.toLowerCase().includes('lower') ? 'lower' : 'normal',
    },
    {
      icon: 'temperature.png',
      label: 'Temperature',
      value: `${latest?.temperature?.value ?? '--'}°F`,
      status: latest?.temperature?.levels || 'Normal',
      state: 'normal',
    },
    {
      icon: 'heart.png',
      label: 'Heart Rate',
      value: `${latest?.heart_rate?.value ?? '--'} bpm`,
      status: latest?.heart_rate?.levels || 'Lower than Average',
      state: latest?.heart_rate?.levels?.toLowerCase().includes('lower') ? 'lower' : 'higher',
    },
  ];

  els.vitalGrid.innerHTML = '';
  const template = els.vitalTemplate.content.firstElementChild;
  items.forEach((item) => {
    const card = template.cloneNode(true);
    card.querySelector('.vital-icon').replaceWith(makeVitalIcon(item.icon));
    card.querySelector('.vital-label').textContent = item.label;
    card.querySelector('.vital-value').textContent = item.value;
    const status = card.querySelector('.vital-status');
    status.textContent = item.status;
    status.dataset.state = item.state;
    els.vitalGrid.appendChild(card);
  });
}

function renderDiagnostics(patient) {
  const rows = patient?.diagnostic_list || patient?.diagnosticList || [];
  els.diagnosticRows.innerHTML = rows.length
    ? rows.map((row) => `
      <tr>
        <td>${escapeHtml(row.name || row.problem || '-')}</td>
        <td>${escapeHtml(row.description || '-')}</td>
        <td>${escapeHtml(row.status || '-')}</td>
      </tr>
    `).join('')
    : '<tr><td colspan="3">No diagnostic data available.</td></tr>';
}

function renderLabResults(patient) {
  const results = patient?.lab_results || [];
  els.labResults.innerHTML = results.length
    ? results.map((item) => `
      <div class="lab-item">
        <div class="lab-name">${escapeHtml(item)}</div>
        <img class="lab-download" src="assets/download.svg" alt="Download" />
      </div>
    `).join('')
    : '<div class="lab-item"><div class="lab-name">No lab results available.</div></div>';
}

function drawChart(patient) {
  const svg = els.bpChart;
  const history = sortHistory(patient?.diagnosis_history || []).slice(-6);
  svg.innerHTML = '';

  const width = 655;
  const height = 260;
  const pad = { top: 18, right: 12, bottom: 34, left: 34 };
  const innerWidth = width - pad.left - pad.right;
  const innerHeight = height - pad.top - pad.bottom;

  const systolic = history.map((entry) => Number(entry?.blood_pressure?.systolic?.value || 0));
  const diastolic = history.map((entry) => Number(entry?.blood_pressure?.diastolic?.value || 0));
  const values = [...systolic, ...diastolic].filter((v) => Number.isFinite(v) && v > 0);
  const min = Math.max(40, Math.min(...values) - 10);
  const max = Math.max(...values) + 10;
  const range = Math.max(1, max - min);

  const xFor = (i) => pad.left + (history.length === 1 ? innerWidth / 2 : (i / (history.length - 1)) * innerWidth);
  const yFor = (v) => pad.top + (1 - ((v - min) / range)) * innerHeight;

  [max, min + range / 4 * 3, min + range / 2, min + range / 4, min].forEach((value) => {
    const y = yFor(value);
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    line.setAttribute('x1', pad.left);
    line.setAttribute('y1', y.toFixed(2));
    line.setAttribute('x2', width - pad.right);
    line.setAttribute('y2', y.toFixed(2));
    line.setAttribute('class', 'bp-grid-line');
    svg.appendChild(line);

    const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    label.setAttribute('x', 0);
    label.setAttribute('y', (y + 4).toFixed(2));
    label.setAttribute('class', 'bp-axis-label');
    label.textContent = Math.round(value).toString();
    svg.appendChild(label);
  });

  const makePath = (series) => series.map((point, index) => `${index === 0 ? 'M' : 'L'} ${xFor(index).toFixed(2)} ${yFor(point).toFixed(2)}`).join(' ');

  const curvePath = (series) => {
    if (!series.length) return '';
    if (series.length < 2) return makePath(series);
    const points = series.map((value, index) => [xFor(index), yFor(value)]);
    let d = `M ${points[0][0].toFixed(2)} ${points[0][1].toFixed(2)}`;
    for (let i = 0; i < points.length - 1; i += 1) {
      const p0 = points[i - 1] || points[i];
      const p1 = points[i];
      const p2 = points[i + 1];
      const p3 = points[i + 2] || p2;
      const cp1x = p1[0] + (p2[0] - p0[0]) / 6;
      const cp1y = p1[1] + (p2[1] - p0[1]) / 6;
      const cp2x = p2[0] - (p3[0] - p1[0]) / 6;
      const cp2y = p2[1] - (p3[1] - p1[1]) / 6;
      d += ` C ${cp1x.toFixed(2)} ${cp1y.toFixed(2)}, ${cp2x.toFixed(2)} ${cp2y.toFixed(2)}, ${p2[0].toFixed(2)} ${p2[1].toFixed(2)}`;
    }
    return d;
  };

  const systolicPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  systolicPath.setAttribute('d', curvePath(systolic));
  systolicPath.setAttribute('class', 'bp-line systolic');
  svg.appendChild(systolicPath);

  const diastolicPath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  diastolicPath.setAttribute('d', curvePath(diastolic));
  diastolicPath.setAttribute('class', 'bp-line diastolic');
  svg.appendChild(diastolicPath);

  history.forEach((entry, index) => {
    const sx = xFor(index);
    const sy = yFor(systolic[index]);
    const dx = xFor(index);
    const dy = yFor(diastolic[index]);

    const systolicCircle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    systolicCircle.setAttribute('cx', sx.toFixed(2));
    systolicCircle.setAttribute('cy', sy.toFixed(2));
    systolicCircle.setAttribute('r', '5.5');
    systolicCircle.setAttribute('fill', '#d85db7');
    systolicCircle.setAttribute('class', 'bp-point');
    svg.appendChild(systolicCircle);

    const diastolicCircle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    diastolicCircle.setAttribute('cx', dx.toFixed(2));
    diastolicCircle.setAttribute('cy', dy.toFixed(2));
    diastolicCircle.setAttribute('r', '5.5');
    diastolicCircle.setAttribute('fill', '#8273dd');
    diastolicCircle.setAttribute('class', 'bp-point');
    svg.appendChild(diastolicCircle);

    const label = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    label.setAttribute('x', sx.toFixed(2));
    label.setAttribute('y', '248');
    label.setAttribute('text-anchor', 'middle');
    label.setAttribute('class', 'bp-axis-label');
    label.textContent = `${monthShort[entry.month] || entry.month?.slice(0, 3) || ''}, ${entry.year || ''}`;
    svg.appendChild(label);
  });

  const latest = history[history.length - 1] || {};
  const bp = latest.blood_pressure || {};
  els.systolicValue.textContent = bp.systolic?.value ?? '--';
  els.systolicHint.textContent = bp.systolic?.levels || 'Higher than average';
  els.diastolicValue.textContent = bp.diastolic?.value ?? '--';
  els.diastolicHint.textContent = bp.diastolic?.levels || 'Lower than average';
}

function formatDate(isoDate) {
  const date = new Date(isoDate);
  if (Number.isNaN(date.getTime())) return isoDate;
  return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
}

async function init() {
  let patients = fallbackData;
  try {
    patients = normalizePatients(await fetchPatients());
  } catch (error) {
    console.warn('Falling back to local data because the API call failed.', error);
  }

  const jessica = findJessica(patients);
  renderPatientsList(patients);
  renderProfile(jessica);
  renderVitals(jessica);
  renderDiagnostics(jessica);
  renderLabResults(jessica);
  drawChart(jessica);

}

document.addEventListener('DOMContentLoaded', () => {
  init().catch((error) => console.error(error));
});
