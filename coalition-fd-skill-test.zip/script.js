// Paste the exact Basic auth token from the challenge docs here.
// The value should be the token that comes after "Basic ", not the word Basic itself.
const AUTH_KEY = "REPLACE_WITH_ENCRYPTED_AUTH_KEY";
const API_URL = "https://fedskillstest.coalitiontechnologies.workers.dev";

const fallbackData = [
  {
    name: "Jessica Taylor",
    gender: "Female",
    age: 28,
    profile_picture: "https://fedskillstest.ct.digital/4.png",
    date_of_birth: "1996-08-23",
    phone_number: "(415) 555-1234",
    emergency_contact: "(415) 555-5678",
    insurance_type: "Sunrise Health Assurance",
    diagnosis_history: [
      { month: "March", year: 2024, blood_pressure: { systolic: { value: 160, levels: "Higher than Average" }, diastolic: { value: 78, levels: "Lower than Average" } }, heart_rate: { value: 78, levels: "Lower than Average" }, respiratory_rate: { value: 20, levels: "Normal" }, temperature: { value: 98.6, levels: "Normal" } },
      { month: "April", year: 2024, blood_pressure: { systolic: { value: 118, levels: "Normal" }, diastolic: { value: 70, levels: "Normal" } }, heart_rate: { value: 76, levels: "Normal" }, respiratory_rate: { value: 19, levels: "Normal" }, temperature: { value: 98.4, levels: "Normal" } },
      { month: "May", year: 2024, blood_pressure: { systolic: { value: 125, levels: "Normal" }, diastolic: { value: 72, levels: "Normal" } }, heart_rate: { value: 80, levels: "Normal" }, respiratory_rate: { value: 20, levels: "Normal" }, temperature: { value: 98.7, levels: "Normal" } },
      { month: "June", year: 2024, blood_pressure: { systolic: { value: 150, levels: "Higher than Average" }, diastolic: { value: 74, levels: "Lower than Average" } }, heart_rate: { value: 82, levels: "Normal" }, respiratory_rate: { value: 21, levels: "Normal" }, temperature: { value: 98.5, levels: "Normal" } },
      { month: "July", year: 2024, blood_pressure: { systolic: { value: 155, levels: "Higher than Average" }, diastolic: { value: 77, levels: "Lower than Average" } }, heart_rate: { value: 79, levels: "Normal" }, respiratory_rate: { value: 20, levels: "Normal" }, temperature: { value: 98.6, levels: "Normal" } },
      { month: "August", year: 2024, blood_pressure: { systolic: { value: 160, levels: "Higher than Average" }, diastolic: { value: 78, levels: "Lower than Average" } }, heart_rate: { value: 78, levels: "Lower than Average" }, respiratory_rate: { value: 20, levels: "Normal" }, temperature: { value: 98.6, levels: "Normal" } },
    ],
    diagnostic_list: [
      { name: "Hypertension", description: "Chronic high blood pressure", status: "Under Observation" },
      { name: "Hyperlipidemia", description: "Elevated cholesterol", status: "Treated" },
      { name: "Seasonal Allergies", description: "Allergic rhinitis", status: "Managed" },
    ],
    lab_results: ["Blood Tests", "CT Scans", "X-Rays", "Urine Analysis"],
  },
];

const monthOrder = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

const el = (sel) => document.querySelector(sel);

function normalizePatients(data) {
  if (Array.isArray(data)) return data;
  if (data && Array.isArray(data.patients)) return data.patients;
  if (data && typeof data === "object") return [data];
  return fallbackData;
}

function getPatientData() {
  const headers = {
    Authorization: `Basic ${AUTH_KEY}`,
  };
  return fetch(API_URL, { method: "GET", headers }).then(async (res) => {
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  });
}

function fmtMonth(entry) {
  return `${entry.month} ${entry.year ?? ""}`.trim();
}

function pickJessica(patients) {
  return patients.find((p) => String(p.name || "").toLowerCase() === "jessica taylor") || patients[0] || fallbackData[0];
}

function latestVitals(patient) {
  const history = Array.isArray(patient.diagnosis_history) ? patient.diagnosis_history : [];
  return history[history.length - 1] || null;
}

function getBpSeries(history) {
  const items = Array.isArray(history) ? history.slice() : [];
  const sorted = items.sort((a, b) => monthOrder.indexOf(a.month) - monthOrder.indexOf(b.month));
  return sorted.slice(-6);
}

function renderPatientsList(patients, selectedName) {
  const list = el("#patientsList");
  const template = el("#patientItemTemplate");
  list.innerHTML = "";

  patients.forEach((patient) => {
    const node = template.content.firstElementChild.cloneNode(true);
    node.classList.toggle("active", patient.name === selectedName);
    node.querySelector(".patient-name").textContent = patient.name;
    node.querySelector(".patient-sub").textContent = `${patient.gender || ""}${patient.age != null ? `, ${patient.age}` : ""}`.trim();
    const img = node.querySelector(".patient-avatar");
    img.src = patient.profile_picture || fallbackData[0].profile_picture;
    img.alt = patient.name;
    list.appendChild(node);
  });
}

function renderProfile(patient) {
  el("#profilePicture").src = patient.profile_picture || fallbackData[0].profile_picture;
  el("#patientName").textContent = patient.name || "Jessica Taylor";

  const meta = [
    ["Date of Birth", patient.date_of_birth || "-"],
    ["Gender", patient.gender || "-"],
    ["Contact Info", patient.phone_number || "-"],
    ["Emergency Contacts", patient.emergency_contact || "-"],
    ["Insurance Provider", patient.insurance_type || "-"],
  ];

  el("#profileMeta").innerHTML = meta.map(([label, value]) => `
    <div class="meta-row"><div class="meta-label">${label}</div><div class="meta-value">${value}</div></div>
  `).join("");
}

function renderVitals(patient) {
  const latest = latestVitals(patient);
  const vitals = [
    { label: "Respiratory Rate", value: latest?.respiratory_rate?.value ?? "--", status: latest?.respiratory_rate?.levels ?? "Normal" },
    { label: "Temperature", value: latest ? `${latest.temperature?.value ?? "--"}°F` : "--", status: latest?.temperature?.levels ?? "Normal" },
    { label: "Heart Rate", value: latest ? `${latest.heart_rate?.value ?? "--"} bpm` : "--", status: latest?.heart_rate?.levels ?? "Normal" },
  ];

  const grid = el("#vitalsGrid");
  const template = el("#vitalTemplate");
  grid.innerHTML = "";

  vitals.forEach((vital) => {
    const card = template.content.firstElementChild.cloneNode(true);
    card.querySelector(".vital-label").textContent = vital.label;
    card.querySelector(".vital-value").textContent = vital.value;
    card.querySelector(".vital-status").textContent = vital.status;
    grid.appendChild(card);
  });
}

function renderDiagnostics(patient) {
  const rows = patient.diagnostic_list || patient.diagnostics || [];
  el("#diagnosticRows").innerHTML = rows.map((row) => `
    <tr>
      <td>${row.name || row.problem || "-"}</td>
      <td>${row.description || "-"}</td>
      <td>${row.status || "-"}</td>
    </tr>
  `).join("") || `<tr><td colspan="3">No diagnostic data available.</td></tr>`;
}

function renderLabResults(patient) {
  const results = patient.lab_results || [];
  el("#labResults").innerHTML = results.map((item) => `
    <div class="lab-item">
      <div class="lab-name">${item}</div>
      <div class="lab-download">⤓</div>
    </div>
  `).join("") || `<div class="lab-item"><div class="lab-name">No lab results available.</div></div>`;
}

function svgEl(name, attrs = {}) {
  const node = document.createElementNS("http://www.w3.org/2000/svg", name);
  Object.entries(attrs).forEach(([k, v]) => node.setAttribute(k, String(v)));
  return node;
}

function renderChart(patient) {
  const svg = el("#bpChart");
  svg.innerHTML = "";

  const history = getBpSeries(patient.diagnosis_history || []);
  const w = 760;
  const h = 320;
  const pad = { top: 24, right: 28, bottom: 40, left: 44 };
  const innerW = w - pad.left - pad.right;
  const innerH = h - pad.top - pad.bottom;

  const systolic = history.map((d) => d.blood_pressure?.systolic?.value ?? 0);
  const diastolic = history.map((d) => d.blood_pressure?.diastolic?.value ?? 0);
  const allVals = systolic.concat(diastolic).filter(Boolean);
  const min = Math.min(...allVals) - 10;
  const max = Math.max(...allVals) + 10;

  const x = (i) => pad.left + (history.length === 1 ? innerW / 2 : (i / (history.length - 1)) * innerW);
  const y = (v) => pad.top + (1 - (v - min) / (max - min)) * innerH;

  for (let i = 0; i < 5; i++) {
    const gy = pad.top + (i / 4) * innerH;
    svg.appendChild(svgEl("line", { x1: pad.left, y1: gy, x2: w - pad.right, y2: gy, stroke: "#eaf1f7", "stroke-width": 1 }));
  }

  const makePath = (values) => values.map((v, i) => `${i === 0 ? "M" : "L"} ${x(i)} ${y(v)}`).join(" ");

  const systolicPath = svgEl("path", {
    d: makePath(systolic), fill: "none", stroke: "#d94ea8", "stroke-width": 4, "stroke-linecap": "round", "stroke-linejoin": "round",
  });
  const diastolicPath = svgEl("path", {
    d: makePath(diastolic), fill: "none", stroke: "#4f46e5", "stroke-width": 4, "stroke-linecap": "round", "stroke-linejoin": "round",
  });
  svg.appendChild(systolicPath);
  svg.appendChild(diastolicPath);

  history.forEach((d, i) => {
    const sx = x(i), sy = y(systolic[i]), dx = x(i), dy = y(diastolic[i]);
    svg.appendChild(svgEl("circle", { cx: sx, cy: sy, r: 5.5, fill: "#fff", stroke: "#d94ea8", "stroke-width": 3 }));
    svg.appendChild(svgEl("circle", { cx: dx, cy: dy, r: 5.5, fill: "#fff", stroke: "#4f46e5", "stroke-width": 3 }));

    const label = svgEl("text", { x: sx, y: h - 12, "text-anchor": "middle", fill: "#64748b", "font-size": 12, "font-family": "Manrope, sans-serif" });
    label.textContent = d.month.slice(0, 3);
    svg.appendChild(label);
  });

  const latest = history[history.length - 1];
  if (latest?.blood_pressure) {
    el("#systolicValue").textContent = latest.blood_pressure.systolic?.value ?? "--";
    el("#diastolicValue").textContent = latest.blood_pressure.diastolic?.value ?? "--";
    el("#systolicHint").textContent = latest.blood_pressure.systolic?.levels || "Higher than average";
    el("#diastolicHint").textContent = latest.blood_pressure.diastolic?.levels || "Lower than average";
  }
}

async function init() {
  let patients = fallbackData;

  try {
    if (AUTH_KEY && AUTH_KEY !== "REPLACE_WITH_ENCRYPTED_AUTH_KEY") {
      const raw = await getPatientData();
      patients = normalizePatients(raw);
    }
  } catch (err) {
    console.warn("API fetch failed, falling back to local sample data:", err);
  }

  const jessica = pickJessica(patients);
  renderPatientsList(patients, jessica.name);
  renderProfile(jessica);
  renderVitals(jessica);
  renderDiagnostics(jessica);
  renderLabResults(jessica);
  renderChart(jessica);
}

document.addEventListener("DOMContentLoaded", init);
