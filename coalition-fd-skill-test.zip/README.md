# Coalition Technologies FED Skills Test

A responsive single-page HTML implementation of the Adobe XD patient dashboard.

## Files
- `index.html`
- `styles.css`
- `script.js`

## Setup
1. Open `script.js`
2. Replace `REPLACE_WITH_ENCRYPTED_AUTH_KEY` with the exact Basic auth token from the challenge instructions.
3. Open `index.html` in a browser.

## Notes
- The app renders only Jessica Taylor in the main content area.
- If the API call fails or the auth key is not filled in, a local fallback dataset is used so the layout still works.
- The blood pressure chart is drawn with pure SVG, so no external chart library is required.
